export interface NetworkInfo {
  ip: string
  city: string
  region: string
  country: string
  countryCode: string
  isp: string
  timezone: string
  latitude: number
  longitude: number
  asn: string
  dns: {
    resolver: string
    responseTime: string
  }
}

export interface SpeedTestResult {
  type: "download" | "upload" | "ping"
  speed?: number
  ping?: number
  minPing?: number
  maxPing?: number
  jitter?: number
  packetLoss?: number
  duration?: number
  size?: number
  bytesTransferred?: number
}

export interface StreamingBenchmarkResult {
  quality: string
  requiredBitrate: number
  measuredSpeed: number
  minSpeed: number
  maxSpeed: number
  canStream: boolean
  bufferingRisk: "Low" | "Medium" | "High"
  duration: number
  fileSize: number
}

export interface ThroughputResult {
  duration: number
  avgThroughput: number
  minThroughput: number
  maxThroughput: number
  stabilityScore: number
  measurements: Array<{ timestamp: number; speed: number }>
  totalDataTransferred: number
}

export async function getNetworkInfo(): Promise<NetworkInfo> {
  const response = await fetch("/api/network-info")
  if (!response.ok) {
    throw new Error("Failed to fetch network info")
  }
  return response.json()
}

export async function runSpeedTest(testType: "download" | "upload" | "ping", size?: number): Promise<SpeedTestResult> {
  const response = await fetch("/api/speed-test", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ testType, size }),
  })

  if (!response.ok) {
    throw new Error(`Speed test failed: ${response.statusText}`)
  }

  return response.json()
}

export async function runStreamingBenchmark(
  quality: "480p" | "720p" | "1080p" | "4K",
): Promise<StreamingBenchmarkResult> {
  const response = await fetch("/api/streaming-benchmark", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ quality }),
  })

  if (!response.ok) {
    throw new Error(`Streaming benchmark failed: ${response.statusText}`)
  }

  return response.json()
}

export async function runThroughputTest(duration = 10): Promise<ThroughputResult> {
  const response = await fetch("/api/throughput-test", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ duration }),
  })

  if (!response.ok) {
    throw new Error(`Throughput test failed: ${response.statusText}`)
  }

  return response.json()
}

export function getConnectionRating(
  downloadSpeed: number,
  uploadSpeed: number,
  ping: number,
  jitter?: number,
): {
  rating: "Poor" | "Fair" | "Good" | "Excellent"
  color: string
  description: string
  score: number
} {
  let score = 0

  // Download speed scoring (40% weight)
  if (downloadSpeed >= 100) score += 40
  else if (downloadSpeed >= 50) score += 30
  else if (downloadSpeed >= 25) score += 20
  else if (downloadSpeed >= 10) score += 10

  // Upload speed scoring (30% weight)
  if (uploadSpeed >= 20) score += 30
  else if (uploadSpeed >= 10) score += 22
  else if (uploadSpeed >= 5) score += 15
  else if (uploadSpeed >= 1) score += 8

  // Ping scoring (20% weight)
  if (ping <= 20) score += 20
  else if (ping <= 50) score += 15
  else if (ping <= 100) score += 10
  else if (ping <= 200) score += 5

  // Jitter scoring (10% weight)
  if (jitter !== undefined) {
    if (jitter <= 5) score += 10
    else if (jitter <= 15) score += 7
    else if (jitter <= 30) score += 4
    else if (jitter <= 50) score += 2
  } else {
    score += 5 // Default if jitter not provided
  }

  if (score >= 85) {
    return {
      rating: "Excellent",
      color: "text-emerald-600",
      description: "Perfect for 4K streaming, gaming, and large file transfers",
      score,
    }
  } else if (score >= 65) {
    return {
      rating: "Good",
      color: "text-emerald-500",
      description: "Great for HD streaming, video calls, and general browsing",
      score,
    }
  } else if (score >= 40) {
    return {
      rating: "Fair",
      color: "text-yellow-500",
      description: "Suitable for basic streaming and web browsing",
      score,
    }
  } else {
    return {
      rating: "Poor",
      color: "text-red-500",
      description: "May experience issues with streaming and large downloads",
      score,
    }
  }
}
