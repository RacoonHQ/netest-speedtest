"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw, Zap, Wifi } from "lucide-react"
import { runSpeedTest, getConnectionRating, type SpeedTestResult } from "@/lib/network-utils"

type TestState = "idle" | "testing" | "completed"
type TestPhase = "ping" | "download" | "upload" | "complete"
type ConnectionType = "multi" | "single"

interface SpeedTestCardProps {
  isTestRunning?: boolean
}

function AnimatedNumber({
  value,
  label,
  unit,
  color,
  isAnimating = false,
}: {
  value: number
  label: string
  unit: string
  color: string
  isAnimating?: boolean
}) {
  const [displayValue, setDisplayValue] = useState(0)

  useEffect(() => {
    if (isAnimating) {
      // Real-time fluctuation during testing
      const interval = setInterval(() => {
        setDisplayValue(value + (Math.random() - 0.5) * (value * 0.2))
      }, 100)
      return () => clearInterval(interval)
    } else {
      // Smooth animation to final value
      const duration = 2000
      const startTime = Date.now()
      const startValue = displayValue

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)
        const easeOut = 1 - Math.pow(1 - progress, 3)

        setDisplayValue(startValue + (value - startValue) * easeOut)

        if (progress < 1) {
          requestAnimationFrame(animate)
        }
      }

      requestAnimationFrame(animate)
    }
  }, [value, isAnimating])

  return (
    <div className="text-center p-6 bg-card/20 backdrop-blur-sm rounded-2xl border border-border/30">
      <div className="mb-3">
        <div className="text-5xl font-bold mb-1" style={{ color }}>
          {displayValue.toFixed(unit === "ms" ? 0 : 1)}
        </div>
        <div className="text-lg text-muted-foreground font-medium">{unit}</div>
      </div>
      <div className="text-base font-semibold text-foreground">{label}</div>
    </div>
  )
}

export function SpeedTestCard({ isTestRunning = false }: SpeedTestCardProps) {
  const [testState, setTestState] = useState<TestState>("idle")
  const [testPhase, setTestPhase] = useState<TestPhase>("ping")
  const [progress, setProgress] = useState(0)
  const [connectionType, setConnectionType] = useState<ConnectionType>("multi")
  const [currentValues, setCurrentValues] = useState({
    download: 0,
    upload: 0,
    ping: 0,
  })
  const [results, setResults] = useState<{
    ping?: SpeedTestResult
    download?: SpeedTestResult
    upload?: SpeedTestResult
  }>({})

  useEffect(() => {
    if (isTestRunning && testState === "idle") {
      startSpeedTest()
    }
  }, [isTestRunning, testState])

  const startSpeedTest = async () => {
    setTestState("testing")
    setTestPhase("ping")
    setProgress(0)
    setResults({})
    setCurrentValues({ download: 0, upload: 0, ping: 0 })

    try {
      // Ping Test
      setProgress(10)
      const pingAnimation = setInterval(() => {
        setCurrentValues((prev) => ({
          ...prev,
          ping: Math.random() * 100 + 50, // Random ping between 50-150ms during test
        }))
      }, 100)

      const pingResult = await runSpeedTest("ping")
      clearInterval(pingAnimation)
      setCurrentValues((prev) => ({ ...prev, ping: pingResult.ping || 0 }))
      setResults((prev) => ({ ...prev, ping: pingResult }))
      setProgress(33)

      // Download Test
      setTestPhase("download")
      const downloadAnimation = setInterval(() => {
        setCurrentValues((prev) => ({
          ...prev,
          download: Math.random() * 80 + 20, // Random speed between 20-100 Mbps during test
        }))
      }, 150)

      const downloadResult = await runSpeedTest("download", 5 * 1024 * 1024) // 5MB
      clearInterval(downloadAnimation)
      setCurrentValues((prev) => ({ ...prev, download: downloadResult.speed || 0 }))
      setResults((prev) => ({ ...prev, download: downloadResult }))
      setProgress(66)

      // Upload Test
      setTestPhase("upload")
      const uploadAnimation = setInterval(() => {
        setCurrentValues((prev) => ({
          ...prev,
          upload: Math.random() * 40 + 10, // Random speed between 10-50 Mbps during test
        }))
      }, 150)

      const uploadResult = await runSpeedTest("upload", 2 * 1024 * 1024) // 2MB
      clearInterval(uploadAnimation)
      setCurrentValues((prev) => ({ ...prev, upload: uploadResult.speed || 0 }))
      setResults((prev) => ({ ...prev, upload: uploadResult }))
      setProgress(100)

      setTestPhase("complete")
      setTestState("completed")
    } catch (error) {
      console.error("Speed test failed:", error)
      setTestState("idle")
      setProgress(0)
      setCurrentValues({ download: 0, upload: 0, ping: 0 })
    }
  }

  const resetTest = () => {
    setTestState("idle")
    setTestPhase("ping")
    setProgress(0)
    setResults({})
    setCurrentValues({ download: 0, upload: 0, ping: 0 })
  }

  const getPhaseText = () => {
    switch (testPhase) {
      case "ping":
        return "Mengukur latensi koneksi..."
      case "download":
        return "Mengukur kecepatan download..."
      case "upload":
        return "Mengukur kecepatan upload..."
      case "complete":
        return "Tes selesai!"
      default:
        return "Siap untuk memulai tes"
    }
  }

  const rating =
    results.download && results.upload && results.ping
      ? getConnectionRating(
          results.download.speed || 0,
          results.upload.speed || 0,
          results.ping.ping || 0,
          results.ping.jitter,
        )
      : null

  return (
    <div className="w-full">
      <div className="text-center mb-8">
        <h2 className="flex items-center justify-center gap-2 text-2xl font-bold mb-2">
          <Zap className="w-7 h-7 text-primary" />
          Tes Kecepatan Internet
        </h2>
        <p className="text-muted-foreground text-lg">
          {testState === "idle" && "Klik tombol START untuk memulai pengujian"}
          {testState === "testing" && "Sedang menganalisis koneksi internet Anda..."}
          {testState === "completed" && "Hasil analisis koneksi internet Anda"}
        </p>
      </div>

      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center gap-4 p-2 bg-card/30 backdrop-blur-sm rounded-full border border-border/50">
          <span className="text-sm font-medium text-muted-foreground px-3">Koneksi</span>
          <button
            onClick={() => setConnectionType("multi")}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
              connectionType === "multi"
                ? "bg-primary text-primary-foreground shadow-lg"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Multi
          </button>
          <div className="w-8 h-8 flex items-center justify-center">
            <Wifi className="w-4 h-4 text-primary" />
          </div>
          <button
            onClick={() => setConnectionType("single")}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
              connectionType === "single"
                ? "bg-primary text-primary-foreground shadow-lg"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Tunggal
          </button>
        </div>
      </div>

      <div className="space-y-8">
        {/* Test Progress */}
        {testState === "testing" && (
          <div className="text-center space-y-6">
            <div className="flex items-center justify-center gap-3">
              <div className="animate-spin rounded-full h-8 w-8 border-4 border-primary border-t-transparent" />
              <span className="text-xl font-semibold text-primary">{getPhaseText()}</span>
            </div>
            <div className="max-w-lg mx-auto">
              <Progress value={progress} className="h-4" />
              <div className="flex justify-between text-sm text-muted-foreground mt-3">
                <span className={testPhase === "ping" ? "text-primary font-semibold" : ""}>Ping</span>
                <span className={testPhase === "download" ? "text-primary font-semibold" : ""}>Download</span>
                <span className={testPhase === "upload" ? "text-primary font-semibold" : ""}>Upload</span>
              </div>
            </div>

            <div className="grid gap-8 md:grid-cols-3 mt-12">
              <AnimatedNumber
                value={currentValues.download}
                label="Download"
                unit="Mbps"
                color="#10B981"
                isAnimating={testState === "testing"}
              />
              <AnimatedNumber
                value={currentValues.upload}
                label="Upload"
                unit="Mbps"
                color="#3B82F6"
                isAnimating={testState === "testing"}
              />
              <AnimatedNumber
                value={currentValues.ping}
                label="Ping"
                unit="ms"
                color="#F59E0B"
                isAnimating={testState === "testing"}
              />
            </div>
          </div>
        )}

        {/* Results Display */}
        {testState === "completed" && (
          <div className="space-y-10">
            {/* Overall Rating */}
            {rating && (
              <div className="text-center p-8 bg-gradient-to-br from-primary/10 to-primary/20 backdrop-blur-sm rounded-2xl border border-primary/30">
                <div className="flex items-center justify-center gap-4 mb-4">
                  <Badge
                    variant="default"
                    className="bg-yellow-500/90 border-2 border-yellow-400 text-black text-xl px-6 py-3 font-bold shadow-lg"
                  >
                    {rating.rating}
                  </Badge>
                  <div className="text-center">
                    <div className="text-5xl font-bold text-primary">{rating.score}</div>
                    <div className="text-base text-gray-300 font-medium">dari 100</div>
                  </div>
                </div>
                <p className="text-lg text-gray-200 max-w-lg mx-auto font-medium">{rating.description}</p>
              </div>
            )}

            <div className="grid gap-10 md:grid-cols-3">
              {results.download && (
                <AnimatedNumber
                  value={results.download.speed || 0}
                  label="Download"
                  unit="Mbps"
                  color="#10B981"
                  isAnimating={false}
                />
              )}

              {results.upload && (
                <AnimatedNumber
                  value={results.upload.speed || 0}
                  label="Upload"
                  unit="Mbps"
                  color="#3B82F6"
                  isAnimating={false}
                />
              )}

              {results.ping && (
                <AnimatedNumber
                  value={results.ping.ping || 0}
                  label="Ping"
                  unit="ms"
                  color="#F59E0B"
                  isAnimating={false}
                />
              )}
            </div>

            <div className="text-center pt-6">
              <Button
                onClick={resetTest}
                variant="outline"
                size="lg"
                className="gap-2 bg-card/50 backdrop-blur-sm border-border/50 hover:bg-card/80 px-8 py-3"
              >
                <RotateCcw className="w-5 h-5" />
                Tes Ulang
              </Button>
            </div>
          </div>
        )}

        {/* Idle State */}
        {testState === "idle" && !isTestRunning && (
          <div className="text-center py-16">
            <div className="w-32 h-32 mx-auto mb-8 bg-primary/10 rounded-full flex items-center justify-center">
              <Zap className="w-16 h-16 text-primary" />
            </div>
            <h3 className="text-2xl font-bold mb-3">Siap Memulai Tes</h3>
            <p className="text-muted-foreground mb-8 max-w-lg mx-auto text-lg">
              Klik tombol START di atas untuk memulai pengujian kecepatan internet Anda. Tes akan mengukur ping,
              download, dan upload speed.
            </p>
            <Button onClick={startSpeedTest} size="lg" className="gap-2 px-8 py-3">
              <Play className="w-5 h-5" />
              Mulai Tes Manual
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
