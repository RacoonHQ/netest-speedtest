"use client"

import { useEffect, useState } from "react"

interface SpeedometerProps {
  value: number
  maxValue: number
  label: string
  unit: string
  color: string
  size?: number
  isAnimating?: boolean
}

export function Speedometer({
  value,
  maxValue,
  label,
  unit,
  color,
  size = 160,
  isAnimating = false,
}: SpeedometerProps) {
  const [animatedValue, setAnimatedValue] = useState(0)
  const [displayValue, setDisplayValue] = useState(0)

  useEffect(() => {
    if (isAnimating && value > 0) {
      const startTime = Date.now()
      const duration = 2000
      const startValue = animatedValue

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)

        const easeOut = 1 - Math.pow(1 - progress, 3)
        const currentValue = startValue + (value - startValue) * easeOut

        setAnimatedValue(currentValue)
        setDisplayValue(currentValue)

        if (progress < 1) {
          requestAnimationFrame(animate)
        }
      }

      requestAnimationFrame(animate)
    } else if (!isAnimating) {
      const timer = setTimeout(() => {
        setAnimatedValue(value)
        setDisplayValue(value)
      }, 100)
      return () => clearTimeout(timer)
    }
  }, [value, isAnimating, animatedValue])

  useEffect(() => {
    if (isAnimating && value === 0) {
      setAnimatedValue(0)
      setDisplayValue(0)
    }
  }, [isAnimating, value])

  const radius = size / 2 - 20
  const circumference = 2 * Math.PI * radius
  const strokeDasharray = circumference * 0.75
  const strokeDashoffset = strokeDasharray - (animatedValue / maxValue) * strokeDasharray

  const generateScaleNumbers = () => {
    const numbers = []
    if (maxValue <= 100) {
      numbers.push(0, 5, 10, 25, 50, 75, 100)
    } else if (maxValue <= 200) {
      numbers.push(0, 10, 25, 50, 100, 150, 200)
    } else {
      numbers.push(0, 50, 100, 250, 500, 750, 1000)
    }
    return numbers.filter((n) => n <= maxValue)
  }

  const scaleNumbers = generateScaleNumbers()

  const getNumberPosition = (number: number, index: number) => {
    const angle = -135 + (270 * index) / (scaleNumbers.length - 1)
    const radian = (angle * Math.PI) / 180
    const numberRadius = radius + 15
    const x = size / 2 + numberRadius * Math.cos(radian)
    const y = size / 2 + numberRadius * Math.sin(radian)
    return { x, y, angle }
  }

  return (
    <div className="relative flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {/* Background arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#374151"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={strokeDasharray}
            strokeDashoffset="0"
            transform={`rotate(-135 ${size / 2} ${size / 2})`}
          />

          {/* Progress arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={strokeDasharray}
            strokeDashoffset={strokeDashoffset}
            className={isAnimating ? "transition-none" : "transition-all duration-2000 ease-out"}
            transform={`rotate(-135 ${size / 2} ${size / 2})`}
          />

          {/* Scale tick marks */}
          {scaleNumbers.map((number, index) => {
            const angle = -135 + (270 * index) / (scaleNumbers.length - 1)
            const radian = (angle * Math.PI) / 180
            const tickStart = radius - 8
            const tickEnd = radius + 2
            const x1 = size / 2 + tickStart * Math.cos(radian)
            const y1 = size / 2 + tickStart * Math.sin(radian)
            const x2 = size / 2 + tickEnd * Math.cos(radian)
            const y2 = size / 2 + tickEnd * Math.sin(radian)

            return <line key={number} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#9CA3AF" strokeWidth="2" />
          })}
        </svg>

        {/* Scale numbers */}
        {scaleNumbers.map((number, index) => {
          const { x, y } = getNumberPosition(number, index)
          return (
            <div
              key={number}
              className="absolute text-xs font-semibold text-gray-300"
              style={{
                left: x - 10,
                top: y - 8,
                width: 20,
                textAlign: "center",
              }}
            >
              {number}
            </div>
          )
        })}

        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-3xl font-bold text-white">{displayValue.toFixed(2)}</div>
          <div className="text-sm text-gray-300 font-medium">{unit}</div>
        </div>
      </div>

      <div className="mt-3 text-lg font-semibold text-center text-white">{label}</div>
    </div>
  )
}
