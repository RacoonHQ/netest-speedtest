"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BarChart3, Activity, Zap } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import {
  runThroughputTest,
  runStreamingBenchmark,
  type ThroughputResult,
  type StreamingBenchmarkResult,
} from "@/lib/network-utils"

export function TestResultsCard() {
  const [throughputData, setThroughputData] = useState<ThroughputResult | null>(null)
  const [streamingData, setStreamingData] = useState<StreamingBenchmarkResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<"throughput" | "streaming">("throughput")

  const runThroughputAnalysis = async () => {
    setIsLoading(true)
    try {
      const result = await runThroughputTest(10) // 10 second test
      setThroughputData(result)
    } catch (error) {
      console.error("Throughput test failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const runStreamingAnalysis = async () => {
    setIsLoading(true)
    try {
      const qualities = ["480p", "720p", "1080p", "4K"] as const
      const results = []

      for (const quality of qualities) {
        const result = await runStreamingBenchmark(quality)
        results.push(result)
      }

      setStreamingData(results)
    } catch (error) {
      console.error("Streaming benchmark failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const streamingChartData = streamingData.map((item) => ({
    quality: item.quality,
    required: item.requiredBitrate,
    measured: item.measuredSpeed,
    canStream: item.canStream,
  }))

  const COLORS = ["#059669", "#3b82f6", "#f59e0b", "#ef4444"]

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />
          Analitik Lanjutan
        </CardTitle>
        <CardDescription>Analisis performa detail dan benchmark komprehensif</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Tab Navigation */}
        <div className="flex gap-2">
          <Button
            variant={activeTab === "throughput" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTab("throughput")}
            className="gap-2 bg-primary/10 border-primary/30 hover:bg-primary/20"
          >
            <Activity className="w-4 h-4" />
            Throughput
          </Button>
          <Button
            variant={activeTab === "streaming" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTab("streaming")}
            className="gap-2 bg-primary/10 border-primary/30 hover:bg-primary/20"
          >
            <Zap className="w-4 h-4" />
            Streaming
          </Button>
        </div>

        {/* Throughput Analysis */}
        {activeTab === "throughput" && (
          <div className="space-y-4">
            {!throughputData ? (
              <div className="text-center py-8">
                <Activity className="w-12 h-12 mx-auto mb-3 opacity-50 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-4">
                  Jalankan analisis throughput untuk melihat stabilitas koneksi
                </p>
                <Button onClick={runThroughputAnalysis} disabled={isLoading} className="gap-2">
                  {isLoading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary-foreground border-t-transparent" />
                  ) : (
                    <Activity className="w-4 h-4" />
                  )}
                  {isLoading ? "Menganalisis..." : "Mulai Tes Throughput"}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Throughput Stats */}
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="text-center p-4 bg-primary/10 rounded-lg border border-primary/20">
                    <div className="text-2xl font-bold text-primary">{throughputData.avgThroughput.toFixed(1)}</div>
                    <div className="text-xs text-muted-foreground">Rata-rata Mbps</div>
                  </div>
                  <div className="text-center p-4 bg-green-500/10 rounded-lg border border-green-500/20">
                    <div className="text-2xl font-bold text-green-400">{throughputData.maxThroughput.toFixed(1)}</div>
                    <div className="text-xs text-muted-foreground">Puncak Mbps</div>
                  </div>
                  <div className="text-center p-4 bg-orange-500/10 rounded-lg border border-orange-500/20">
                    <div className="text-2xl font-bold text-orange-400">{throughputData.minThroughput.toFixed(1)}</div>
                    <div className="text-xs text-muted-foreground">Minimum Mbps</div>
                  </div>
                  <div className="text-center p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
                    <div className="text-2xl font-bold text-blue-400">{throughputData.stabilityScore.toFixed(0)}%</div>
                    <div className="text-xs text-muted-foreground">Stabilitas</div>
                  </div>
                </div>

                {/* Throughput Chart */}
                <div className="h-64 bg-muted/20 rounded-lg p-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={throughputData.measurements}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" strokeOpacity={0.8} />
                      <XAxis
                        dataKey="timestamp"
                        tick={{ fontSize: 12, fill: "#9CA3AF" }}
                        tickFormatter={(value) => `${Math.round(value / 1000)}s`}
                        stroke="#6B7280"
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: "#9CA3AF" }}
                        tickFormatter={(value) => `${value} Mbps`}
                        stroke="#6B7280"
                      />
                      <Tooltip
                        formatter={(value: number) => [`${value.toFixed(1)} Mbps`, "Kecepatan"]}
                        labelFormatter={(value) => `Waktu: ${Math.round(Number(value) / 1000)}s`}
                        contentStyle={{
                          backgroundColor: "#1F2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#F9FAFB",
                          boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
                        }}
                        labelStyle={{ color: "#D1D5DB" }}
                      />
                      <Line
                        type="monotone"
                        dataKey="speed"
                        stroke="#10B981"
                        strokeWidth={3}
                        dot={false}
                        activeDot={{ r: 6, fill: "#10B981", stroke: "#065F46", strokeWidth: 2 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Streaming Analysis */}
        {activeTab === "streaming" && (
          <div className="space-y-4">
            {streamingData.length === 0 ? (
              <div className="text-center py-8">
                <Zap className="w-12 h-12 mx-auto mb-3 opacity-50 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-4">
                  Tes kemampuan streaming untuk berbagai kualitas video
                </p>
                <Button onClick={runStreamingAnalysis} disabled={isLoading} className="gap-2">
                  {isLoading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary-foreground border-t-transparent" />
                  ) : (
                    <Zap className="w-4 h-4" />
                  )}
                  {isLoading ? "Menguji..." : "Mulai Tes Streaming"}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Streaming Capabilities */}
                <div className="grid gap-3 md:grid-cols-2">
                  {streamingData.map((item, index) => (
                    <div key={item.quality} className="p-4 bg-muted/20 rounded-lg border border-border/50">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium text-foreground">{item.quality} Video</span>
                        <Badge
                          variant={item.canStream ? "default" : "destructive"}
                          className={item.canStream ? "bg-green-500/20 text-green-400 hover:bg-green-500/20" : ""}
                        >
                          {item.canStream ? "✓ Didukung" : "✗ Tidak Didukung"}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>Dibutuhkan: {item.requiredBitrate} Mbps</div>
                        <div>Terukur: {item.measuredSpeed.toFixed(1)} Mbps</div>
                        <div>Risiko Buffering: {item.bufferingRisk}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Streaming Chart */}
                <div className="h-64 bg-muted/20 rounded-lg p-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={streamingChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" strokeOpacity={0.8} />
                      <XAxis dataKey="quality" tick={{ fontSize: 12, fill: "#9CA3AF" }} stroke="#6B7280" />
                      <YAxis
                        tick={{ fontSize: 12, fill: "#9CA3AF" }}
                        tickFormatter={(value) => `${value} Mbps`}
                        stroke="#6B7280"
                      />
                      <Tooltip
                        formatter={(value: number, name: string) => [`${value} Mbps`, name]}
                        contentStyle={{
                          backgroundColor: "#1F2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#F9FAFB",
                          boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
                        }}
                        labelStyle={{ color: "#D1D5DB" }}
                      />
                      <Bar dataKey="required" fill="#6B7280" name="Dibutuhkan" opacity={0.8} />
                      <Bar dataKey="measured" fill="#10B981" name="Kecepatan Anda" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
