"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Youtube, Monitor, Smartphone, Tv, CheckCircle, XCircle, AlertCircle } from "lucide-react"
import { runStreamingBenchmark, type StreamingBenchmarkResult } from "@/lib/network-utils"

interface StreamingService {
  name: string
  icon: React.ReactNode
  requirements: {
    "480p": number
    "720p": number
    "1080p": number
    "4K": number
  }
}

const streamingServices: StreamingService[] = [
  {
    name: "YouTube",
    icon: <Youtube className="w-4 h-4" />,
    requirements: {
      "480p": 1,
      "720p": 2.5,
      "1080p": 5,
      "4K": 20,
    },
  },
  {
    name: "Netflix",
    icon: <Monitor className="w-4 h-4" />,
    requirements: {
      "480p": 1.5,
      "720p": 3,
      "1080p": 5,
      "4K": 25,
    },
  },
  {
    name: "Disney+",
    icon: <Tv className="w-4 h-4" />,
    requirements: {
      "480p": 1.5,
      "720p": 3.2,
      "1080p": 5.2,
      "4K": 25,
    },
  },
]

export function StreamingBenchmarkCard() {
  const [benchmarkResults, setBenchmarkResults] = useState<StreamingBenchmarkResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [currentTest, setCurrentTest] = useState("")

  const runFullBenchmark = async () => {
    setIsLoading(true)
    setProgress(0)
    setBenchmarkResults([])

    const qualities = ["480p", "720p", "1080p", "4K"] as const
    const results: StreamingBenchmarkResult[] = []

    try {
      for (let i = 0; i < qualities.length; i++) {
        const quality = qualities[i]
        setCurrentTest(`Testing ${quality} streaming...`)
        setProgress((i / qualities.length) * 100)

        const result = await runStreamingBenchmark(quality)
        results.push(result)
        setBenchmarkResults([...results])

        // Small delay for better UX
        await new Promise((resolve) => setTimeout(resolve, 500))
      }

      setProgress(100)
      setCurrentTest("Benchmark completed!")
    } catch (error) {
      console.error("Streaming benchmark failed:", error)
    } finally {
      setIsLoading(false)
      setCurrentTest("")
    }
  }

  const getServiceCompatibility = (service: StreamingService, results: StreamingBenchmarkResult[]) => {
    const compatibility = Object.entries(service.requirements).map(([quality, required]) => {
      const result = results.find((r) => r.quality === quality)
      const canStream = result ? result.measuredSpeed >= required : false
      return {
        quality,
        required,
        measured: result?.measuredSpeed || 0,
        canStream,
        bufferingRisk: result?.bufferingRisk || "Unknown",
      }
    })

    const supportedQualities = compatibility.filter((c) => c.canStream).length
    const maxQuality = compatibility.reverse().find((c) => c.canStream)?.quality || "Not supported"

    return { compatibility: compatibility.reverse(), supportedQualities, maxQuality }
  }

  const getStatusIcon = (canStream: boolean, bufferingRisk: string) => {
    if (canStream && bufferingRisk === "Low") {
      return <CheckCircle className="w-4 h-4 text-emerald-600" />
    } else if (canStream && bufferingRisk === "Medium") {
      return <AlertCircle className="w-4 h-4 text-yellow-600" />
    } else {
      return <XCircle className="w-4 h-4 text-red-600" />
    }
  }

  const getStatusColor = (canStream: boolean, bufferingRisk: string) => {
    if (canStream && bufferingRisk === "Low") return "text-emerald-600"
    if (canStream && bufferingRisk === "Medium") return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="w-5 h-5 text-primary" />
          Streaming Benchmark
        </CardTitle>
        <CardDescription>Test your connection for video streaming services</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Test Controls */}
        <div className="text-center space-y-4">
          {benchmarkResults.length === 0 && !isLoading && (
            <div className="space-y-3">
              <div className="flex items-center justify-center gap-2 text-muted-foreground">
                <Smartphone className="w-5 h-5" />
                <Monitor className="w-5 h-5" />
                <Tv className="w-5 h-5" />
              </div>
              <p className="text-sm text-muted-foreground">
                Test streaming performance across different video qualities
              </p>
              <Button onClick={runFullBenchmark} size="lg" className="gap-2">
                <Play className="w-4 h-4" />
                Start Streaming Benchmark
              </Button>
            </div>
          )}

          {isLoading && (
            <div className="space-y-3">
              <div className="flex items-center justify-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary border-t-transparent" />
                <span className="text-sm font-medium">{currentTest}</span>
              </div>
              <Progress value={progress} className="w-64 mx-auto" />
            </div>
          )}

          {benchmarkResults.length > 0 && !isLoading && (
            <Button onClick={runFullBenchmark} variant="outline" className="gap-2 bg-transparent">
              <Play className="w-4 h-4" />
              Run Again
            </Button>
          )}
        </div>

        {/* Results */}
        {benchmarkResults.length > 0 && (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="services">Services</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              {/* Quality Results Grid */}
              <div className="grid gap-4 md:grid-cols-2">
                {benchmarkResults.map((result) => (
                  <div key={result.quality} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium">{result.quality} Quality</h3>
                      <Badge variant={result.canStream ? "default" : "destructive"}>
                        {result.canStream ? "✓ Supported" : "✗ Not Supported"}
                      </Badge>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Required:</span>
                        <span>{result.requiredBitrate} Mbps</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Your Speed:</span>
                        <span className="font-medium">{result.measuredSpeed.toFixed(1)} Mbps</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Buffering Risk:</span>
                        <Badge
                          variant="outline"
                          className={`text-xs ${
                            result.bufferingRisk === "Low"
                              ? "text-emerald-600 border-emerald-600"
                              : result.bufferingRisk === "Medium"
                                ? "text-yellow-600 border-yellow-600"
                                : "text-red-600 border-red-600"
                          }`}
                        >
                          {result.bufferingRisk}
                        </Badge>
                      </div>
                    </div>

                    {/* Speed Bar */}
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>0 Mbps</span>
                        <span>{Math.max(result.requiredBitrate * 2, result.measuredSpeed)} Mbps</span>
                      </div>
                      <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="absolute left-0 top-0 h-full bg-primary rounded-full transition-all duration-1000"
                          style={{
                            width: `${Math.min((result.measuredSpeed / Math.max(result.requiredBitrate * 2, result.measuredSpeed)) * 100, 100)}%`,
                          }}
                        />
                        <div
                          className="absolute top-0 h-full w-0.5 bg-red-500"
                          style={{
                            left: `${(result.requiredBitrate / Math.max(result.requiredBitrate * 2, result.measuredSpeed)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Recommendations */}
              <div className="p-4 bg-muted/50 rounded-lg">
                <h3 className="font-medium mb-3">Recommendations</h3>
                <div className="space-y-2 text-sm">
                  {benchmarkResults.find((r) => r.quality === "4K")?.canStream ? (
                    <div className="flex items-center gap-2 text-emerald-600">
                      <CheckCircle className="w-4 h-4" />
                      <span>Excellent for 4K streaming on all platforms</span>
                    </div>
                  ) : benchmarkResults.find((r) => r.quality === "1080p")?.canStream ? (
                    <div className="flex items-center gap-2 text-emerald-600">
                      <CheckCircle className="w-4 h-4" />
                      <span>Great for Full HD streaming</span>
                    </div>
                  ) : benchmarkResults.find((r) => r.quality === "720p")?.canStream ? (
                    <div className="flex items-center gap-2 text-yellow-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>Good for HD streaming, may buffer on 4K</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-red-600">
                      <XCircle className="w-4 h-4" />
                      <span>May experience buffering on HD content</span>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="services" className="space-y-4">
              {streamingServices.map((service) => {
                const serviceData = getServiceCompatibility(service, benchmarkResults)

                return (
                  <div key={service.name} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        {service.icon}
                        <h3 className="font-medium">{service.name}</h3>
                      </div>
                      <Badge variant="outline">Max: {serviceData.maxQuality}</Badge>
                    </div>

                    <div className="grid gap-2 md:grid-cols-2">
                      {serviceData.compatibility.map((quality) => (
                        <div
                          key={quality.quality}
                          className="flex items-center justify-between p-2 bg-muted/30 rounded"
                        >
                          <div className="flex items-center gap-2">
                            {getStatusIcon(quality.canStream, quality.bufferingRisk)}
                            <span className="text-sm">{quality.quality}</span>
                          </div>
                          <div className="text-right">
                            <div
                              className={`text-sm font-medium ${getStatusColor(quality.canStream, quality.bufferingRisk)}`}
                            >
                              {quality.measured.toFixed(1)} / {quality.required} Mbps
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  )
}
