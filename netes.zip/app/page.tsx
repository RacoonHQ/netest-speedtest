"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { NetworkInfoCard } from "@/components/network-info-card"
import { SpeedTestCard } from "@/components/speed-test-card"
import { TestResultsCard } from "@/components/test-results-card"
import { StreamingBenchmarkCard } from "@/components/streaming-benchmark-card"
import { getNetworkInfo, type NetworkInfo } from "@/lib/network-utils"
import { Wifi, Globe, Zap, Activity, Play, BarChart3, Github, Gamepad2 } from "lucide-react"

export default function SpeedTestDashboard() {
  const [networkInfo, setNetworkInfo] = useState<NetworkInfo | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isTestRunning, setIsTestRunning] = useState(false)
  const [activeTab, setActiveTab] = useState("speed-test")

  useEffect(() => {
    async function fetchNetworkInfo() {
      try {
        const info = await getNetworkInfo()
        setNetworkInfo(info)
      } catch (err) {
        setError("Failed to load network information")
        console.error("Network info error:", err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchNetworkInfo()
  }, [])

  const handleStartTest = () => {
    setIsTestRunning(true)
    // Run all tests comprehensively
    setTimeout(() => setIsTestRunning(false), 30000)
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="particles-container">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 20}s`,
                animationDuration: `${15 + Math.random() * 10}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-full shadow-lg">
                <Wifi className="w-8 h-8 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Netest</h1>
                <p className="text-sm text-muted-foreground">Test Kecepatan Internet Modern</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="gap-1 border-primary/30 text-primary">
                <Activity className="w-3 h-3" />
                Live Testing
              </Badge>
              <Button variant="ghost" size="sm" className="gap-2">
                <Github className="w-4 h-4" />
                <span className="hidden sm:inline">RacoonHQ</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 relative z-10">
        <div className="text-center py-12 mb-12">
          <h1 className="text-display text-foreground mb-6">
            Tes Kecepatan
            <br />
            <span className="text-primary">Internet Anda</span>
          </h1>
          <p className="text-body max-w-2xl mx-auto">
            Analisis komprehensif koneksi internet Anda dengan teknologi modern dan interface yang ramah pengguna
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-10">
          {/* Left Column - 30% - Network Info & Status */}
          <div className="lg:col-span-3 space-y-6">
            {/* Network Information */}
            <div className="bg-card/50 backdrop-blur-sm rounded-lg border border-border/50">
              <NetworkInfoCard networkInfo={networkInfo} isLoading={isLoading} error={error} />
            </div>

            {/* Status Koneksi */}
            <Card className="bg-card/50 backdrop-blur-sm border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Globe className="w-5 h-5 text-primary" />
                  Status Koneksi
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <Badge variant="default" className="bg-green-500/20 text-green-400 hover:bg-green-500/20">
                    Terhubung
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Protokol</span>
                  <span className="text-sm font-medium">IPv4</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Keamanan</span>
                  <Badge variant="outline" className="border-primary/30 text-primary">
                    HTTPS
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Lokasi Server</span>
                  <span className="text-sm font-medium">Jakarta, ID</span>
                </div>
              </CardContent>
            </Card>

            {/* Rekomendasi Kecepatan */}
            <Card className="bg-card/50 backdrop-blur-sm border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Rekomendasi Kecepatan</CardTitle>
                <CardDescription>Aktivitas yang bisa dilakukan dengan kecepatan Anda</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Browsing Web</span>
                  <Badge variant="outline" className="text-xs border-primary/30">
                    1+ Mbps
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Streaming HD</span>
                  <Badge variant="outline" className="text-xs border-primary/30">
                    5+ Mbps
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Streaming 4K</span>
                  <Badge variant="outline" className="text-xs border-primary/30">
                    25+ Mbps
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Gaming Online</span>
                  <Badge variant="outline" className="text-xs border-primary/30">
                    3+ Mbps
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Video Conference</span>
                  <Badge variant="outline" className="text-xs border-primary/30">
                    1.5+ Mbps
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - 70% - WiFi Button & Test Results */}
          <div className="lg:col-span-7 space-y-6">
            <div className="text-center py-8">
              <div className="relative inline-block">
                <Button
                  size="lg"
                  onClick={handleStartTest}
                  disabled={isTestRunning}
                  className="relative w-48 h-48 md:w-56 md:h-56 rounded-full text-xl font-bold bg-primary hover:bg-primary/90 text-primary-foreground shadow-2xl transition-all duration-300 hover:scale-105"
                >
                  <div className="flex flex-col items-center gap-3">
                    {isTestRunning ? (
                      <>
                        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-foreground border-t-transparent"></div>
                        <span className="text-lg">Testing...</span>
                        <span className="text-sm font-normal">Comprehensive Analysis</span>
                      </>
                    ) : (
                      <>
                        <Wifi className="w-16 h-16 mb-2" />
                        <span className="text-2xl">MULAI</span>
                        <span className="text-sm font-normal">Tes Komprehensif</span>
                      </>
                    )}
                  </div>
                </Button>
              </div>

              {/* Server Info */}
              <div className="flex flex-wrap justify-center gap-4 mt-6">
                <div className="flex items-center gap-2 px-4 py-2 bg-card/50 rounded-full border border-border/50">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-muted-foreground">Server: Jakarta</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-card/50 rounded-full border border-border/50">
                  <Globe className="w-4 h-4 text-primary" />
                  <span className="text-sm text-muted-foreground">IPv4 Connected</span>
                </div>
              </div>
            </div>

            {/* Test Results Tabs */}
            <div className="bg-card/50 backdrop-blur-sm rounded-lg border border-border/50 p-1">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-background/50">
                  <TabsTrigger value="speed-test" className="gap-2">
                    <Zap className="w-4 h-4" />
                    <span className="hidden sm:inline">Kecepatan</span>
                    <span className="sm:hidden">Speed</span>
                  </TabsTrigger>
                  <TabsTrigger value="streaming" className="gap-2">
                    <Play className="w-4 h-4" />
                    <span className="hidden sm:inline">Streaming</span>
                    <span className="sm:hidden">Stream</span>
                  </TabsTrigger>
                  <TabsTrigger value="gaming" className="gap-2">
                    <Gamepad2 className="w-4 h-4" />
                    <span className="hidden sm:inline">Gaming</span>
                    <span className="sm:hidden">Game</span>
                  </TabsTrigger>
                  <TabsTrigger value="analytics" className="gap-2">
                    <BarChart3 className="w-4 h-4" />
                    <span className="hidden sm:inline">Analitik</span>
                    <span className="sm:hidden">Data</span>
                  </TabsTrigger>
                </TabsList>

                <div className="p-6">
                  <TabsContent value="speed-test" className="space-y-6 mt-0">
                    <SpeedTestCard isTestRunning={isTestRunning} />
                  </TabsContent>

                  <TabsContent value="streaming" className="space-y-6 mt-0">
                    <StreamingBenchmarkCard />
                  </TabsContent>

                  <TabsContent value="gaming" className="space-y-6 mt-0">
                    {/* ... existing gaming content ... */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Gamepad2 className="w-5 h-5 text-primary" />
                          Gaming Performance
                        </CardTitle>
                        <CardDescription>Ping benchmarks untuk game populer dan rekomendasi performa</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Gaming content remains the same */}
                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="space-y-3">
                            <h4 className="font-semibold text-sm">MOBA Games</h4>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <span className="text-sm">Mobile Legends</span>
                                <Badge variant="outline" className="text-green-400 border-green-400/30">
                                  &lt; 50ms
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <span className="text-sm">League of Legends</span>
                                <Badge variant="outline" className="text-green-400 border-green-400/30">
                                  &lt; 60ms
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <span className="text-sm">Dota 2</span>
                                <Badge variant="outline" className="text-yellow-400 border-yellow-400/30">
                                  &lt; 80ms
                                </Badge>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <h4 className="font-semibold text-sm">FPS Games</h4>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <span className="text-sm">Valorant</span>
                                <Badge variant="outline" className="text-green-400 border-green-400/30">
                                  &lt; 30ms
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <span className="text-sm">CS2</span>
                                <Badge variant="outline" className="text-green-400 border-green-400/30">
                                  &lt; 40ms
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                <span className="text-sm">PUBG Mobile</span>
                                <Badge variant="outline" className="text-yellow-400 border-yellow-400/30">
                                  &lt; 60ms
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="analytics" className="space-y-6 mt-0">
                    <TestResultsCard />
                  </TabsContent>
                </div>
              </Tabs>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <Card className="bg-card/50 backdrop-blur-sm border-border/50">
            <CardHeader>
              <CardTitle className="text-xl">Informasi Tes</CardTitle>
              <CardDescription>Memahami hasil tes Anda</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6 md:grid-cols-3">
              <div className="space-y-3">
                <h4 className="font-semibold text-base flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  Kecepatan Download
                </h4>
                <p className="text-sm text-muted-foreground">
                  Mengukur seberapa cepat data diunduh ke perangkat Anda. Semakin tinggi semakin baik untuk streaming
                  dan browsing.
                </p>
              </div>
              <div className="space-y-3">
                <h4 className="font-semibold text-base flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  Kecepatan Upload
                </h4>
                <p className="text-sm text-muted-foreground">
                  Mengukur seberapa cepat data diunggah dari perangkat Anda. Penting untuk video call dan berbagi file.
                </p>
              </div>
              <div className="space-y-3">
                <h4 className="font-semibold text-base flex items-center gap-2">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  Ping & Jitter
                </h4>
                <p className="text-sm text-muted-foreground">
                  Ping mengukur waktu respons. Jitter mengukur konsistensi. Semakin rendah semakin baik untuk gaming dan
                  video call.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="relative border-t border-border/50 bg-card/30 backdrop-blur-md mt-12 overflow-hidden">
        <div className="absolute bottom-0 left-0 w-full h-32 overflow-hidden">
          <svg className="absolute bottom-0 w-full h-32" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <defs>
              <linearGradient id="waveGradient1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="oklch(0.6 0.2 180 / 0.3)" />
                <stop offset="50%" stopColor="oklch(0.65 0.2 180 / 0.4)" />
                <stop offset="100%" stopColor="oklch(0.6 0.2 180 / 0.3)" />
              </linearGradient>
              <linearGradient id="waveGradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="oklch(0.6 0.2 180 / 0.2)" />
                <stop offset="50%" stopColor="oklch(0.65 0.2 180 / 0.3)" />
                <stop offset="100%" stopColor="oklch(0.6 0.2 180 / 0.2)" />
              </linearGradient>
              <linearGradient id="waveGradient3" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="oklch(0.6 0.2 180 / 0.15)" />
                <stop offset="50%" stopColor="oklch(0.65 0.2 180 / 0.25)" />
                <stop offset="100%" stopColor="oklch(0.6 0.2 180 / 0.15)" />
              </linearGradient>
            </defs>
            <path
              d="M0,60 C300,120 900,0 1200,60 L1200,120 L0,120 Z"
              fill="url(#waveGradient1)"
              className="wave-layer-1"
            />
            <path
              d="M0,80 C300,40 900,120 1200,80 L1200,120 L0,120 Z"
              fill="url(#waveGradient2)"
              className="wave-layer-2"
            />
            <path
              d="M0,100 C400,60 800,140 1200,100 L1200,120 L0,120 Z"
              fill="url(#waveGradient3)"
              className="wave-layer-3"
            />
          </svg>
        </div>

        <div className="container mx-auto px-4 py-12 relative z-10">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-full">
                  <Wifi className="w-6 h-6 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-foreground">Netest</span>
              </div>
              <p className="text-sm text-muted-foreground max-w-xs">
                Platform tes kecepatan internet modern dengan teknologi terdepan untuk menganalisis performa koneksi
                Anda secara komprehensif.
              </p>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Github className="w-4 h-4" />
                <span>Open Source Project</span>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-foreground">Fitur</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Tes Kecepatan Internet</li>
                <li>Benchmark Streaming</li>
                <li>Gaming Performance</li>
                <li>Analitik Mendalam</li>
              </ul>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-foreground">Dukungan</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Dokumentasi</li>
                <li>FAQ</li>
                <li>Kontak</li>
                <li>Lapor Bug</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Developer</h4>
              <div className="flex items-center gap-3 p-3 bg-muted/20 rounded-lg border border-border/30">
                <div className="flex items-center justify-center w-8 h-8 bg-primary/20 rounded-full">
                  <Github className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="font-medium text-sm">RacoonHQ</div>
                  <div className="text-xs text-muted-foreground">Lead Developer</div>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Dikembangkan dengan passion untuk memberikan pengalaman terbaik dalam menganalisis koneksi internet.
              </p>
            </div>
          </div>

          <Separator className="my-8 bg-border/50" />

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>© 2024 RacoonHQ. All rights reserved.</span>
              <Separator orientation="vertical" className="h-4" />
              <span>Built with Next.js & TailwindCSS</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>Privacy Policy</span>
              <span>Terms of Service</span>
              <div className="flex items-center gap-1">
                <Wifi className="w-3 h-3" />
                <span>Powered by modern web tech</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
